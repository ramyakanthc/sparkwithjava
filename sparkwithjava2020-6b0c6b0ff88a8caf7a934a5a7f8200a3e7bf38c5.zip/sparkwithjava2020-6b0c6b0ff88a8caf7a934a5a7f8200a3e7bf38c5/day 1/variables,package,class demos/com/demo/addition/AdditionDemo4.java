package com.demo.addition;

public class AdditionDemo4 {
	
	// passing parameter in method using package demo
	
	public int Addtion4(int number1, int number2) {

		int result;

		result = number1 + number2; // sub logic

		return result;

	}
}

