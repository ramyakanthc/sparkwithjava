package com.demo.substraction;

//return type demo with package concept

public class SubstractionDemo4 {
	
	// passing parameter in method
	public int Sub4(int number1, int number2) {

		int subresult;

		subresult = number1 - number2; // sub logic

		return subresult; //   need to  implement this

	}
}


