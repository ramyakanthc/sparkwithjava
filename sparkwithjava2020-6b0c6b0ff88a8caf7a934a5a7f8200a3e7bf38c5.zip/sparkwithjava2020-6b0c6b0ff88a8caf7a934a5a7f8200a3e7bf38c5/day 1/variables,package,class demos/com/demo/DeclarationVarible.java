package com.demo;

public class DeclarationVarible {

	public static void main(String arg[]) {

		int number1 = 20;
		int number2 = 10;
		int addresult;
		int subresult;

		
		
		

		
		
		//System.out.print( "sub of two numbers "+subresult);

	}

}
