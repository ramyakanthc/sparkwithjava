package com.demo.operators;

public class AssignmentOperator {
	public static void main(String ar[]) {
		
		
		int a = 10;
		int b = 20;
		
		a += 4;// a=a+4 (a=10+4)
		b -= 4;// b=b-4 (b=20-4)
		System.out.println(a);
		System.out.println(b);
		
		
		
	}

}
