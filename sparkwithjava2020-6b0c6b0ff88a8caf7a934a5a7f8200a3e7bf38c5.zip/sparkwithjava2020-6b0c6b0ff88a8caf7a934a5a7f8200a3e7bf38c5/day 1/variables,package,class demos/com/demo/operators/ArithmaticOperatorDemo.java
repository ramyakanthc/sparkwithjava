package com.demo.operators;

public class ArithmaticOperatorDemo {
	
	public static void main(String ar[]) {
		
		int a = 10;// this is not object
		
		Integer a1 = new Integer(9); //
		
		int b = 5;
		System.out.println(a + b);// 15
		System.out.println(a - b);// 5
		System.out.println(a * b);// 50
		System.out.println(a / b);// 2
		System.out.println(a % b);// 0
		
		
	}

}
