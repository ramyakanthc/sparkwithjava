package com.demo.modifiers;

public class ModifierPublicDemo {

	public void show() {

		System.out.println("hi");
	}

	public static void main(String ar[]) {

		ModifierPublicDemo defaultDemo = new ModifierPublicDemo();

		defaultDemo.show();

	}

}
