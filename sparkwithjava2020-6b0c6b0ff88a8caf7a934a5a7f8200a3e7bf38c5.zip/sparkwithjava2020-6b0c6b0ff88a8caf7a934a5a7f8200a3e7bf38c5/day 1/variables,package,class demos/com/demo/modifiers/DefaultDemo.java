package com.demo.modifiers;

public class DefaultDemo {

	void show() {

		System.out.println("hi");
	}

	public static void main(String ar[]) {

		DefaultDemo defaultDemo = new DefaultDemo();

		defaultDemo.show();

	}

}
