package com.demo;

public class DemoFirstprg {

	public static void main(String arg[]) {

	
		System.out.print(" hi how are you ");

	}

}
